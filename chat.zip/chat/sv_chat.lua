local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","chat")

RegisterServerEvent('chat:init')
RegisterServerEvent('chat:addTemplate')
RegisterServerEvent('chatMessage')
RegisterServerEvent('chat:addSuggestion')
RegisterServerEvent('chat:removeSuggestion')
RegisterServerEvent('_chat:muitzaqmessageEntered')
RegisterServerEvent('chat:clear')
RegisterServerEvent('__cfx_internal:commandFallback')

RegisterServerEvent('chat:kickSpammer')
AddEventHandler('chat:kickSpammer', function()
	TriggerClientEvent('chatMessage', -1, "[^5Krown^0] ^2"..vRP.getPlayerName({source}).."^9 A primit KICK pentru SPAM!")
	DropPlayer(source, 'Ai primit KICK pentru SPAM!')
end)

RegisterServerEvent("clearChat")
AddEventHandler("clearChat", function()
	local user_id = vRP.getUserId({source})
	local name = vRP.getPlayerName({source})
	if user_id ~= nil then
		if vRP.isUserHelper({user_id}) then
			TriggerClientEvent("chat:clear", -1)
			TriggerClientEvent('chatMessage', -1, "[^5Krown^0] ^5[^1"..user_id.."^5] ^1"..name.." ^7a ^6CURATAT ^7chatul!")
		end
	end
end)

local disabled = false

RegisterServerEvent("disableChat")
AddEventHandler("disableChat", function()
	local user_id = vRP.getUserId({source})
	local name = vRP.getPlayerName({source})
	if user_id ~= nil then
		if vRP.isUserHelperAvansat({user_id}) then
			disabled = not disabled
			if disabled then
				TriggerClientEvent('chatMessage', -1, "[^5Krown^0] ^5[^1"..user_id.."^5] ^1"..name.." ^7a ^1DEZACTIVAT ^7chatul!")
			else
				TriggerClientEvent('chatMessage', -1, "[^5Krown^0] ^5[^1"..user_id.."^5] ^1"..name.." ^7a ^5ACTIVAT ^7chatul!")
			end
		end
	end
end)

local mute = {}
local timpmute = {}
--local mutevoice = {}
--local timpmutevoice = {}
local cooldown = {}
local cooldownTime = 0
local chatwebhook = ""
local function cooldownChat(user_id)
	if vRP.isUserMod({user_id}) then
		cooldown[user_id] = nil
	else
		cooldown[user_id] = true
		cooldownTime = 5
		Wait(1000)
		cooldownTime = 4
		Wait(1000)
		cooldownTime = 3
		Wait(1000)
		cooldownTime = 2
		Wait(1000)
		cooldownTime = 1
		Wait(1000)
		cooldown[user_id] = nil
	end
end

function repeats(s,c)
    local _,n = s:gsub(c,"")
    return n
end

--print(repeats("A001BBD0","0"))

AddEventHandler('_chat:muitzaqmessageEntered', function(author, color, message)
	if (repeats(message,":") > 7) then
		TriggerClientEvent('chatMessage', source, "[^5Krown^0] Prea multe emoji-uri in mesaj!")
		return
	end
	if  (string.len(message) > 150) then
		TriggerClientEvent('chatMessage', source, "[^5Krown^0] Prea multe caractere in mesaj!")
		return	
	end
    if not message or not author then
        return
	end
	if source ~= nil then
		local user_id = vRP.getUserId({source})
		if user_id ~= nil then
			if not vRP.isUserTrialHelper({user_id}) or not vRP.hasGroup({user_id,"youtuber"}) or not vRP.hasGroup({user_id,"sponsors"}) or not vRP.isUserVip({user_id}) then
				author = sanitizeString(author, "^", false)
				message = sanitizeString(message, "^", false)
			end
			TriggerEvent('chatMessage', source, author, message)
			if disabled then
				if vRP.isUserTrialHelper({user_id}) then
					tag = "^9[ ^8"..user_id.." ^9] ^8STAFF ^9| ^8"..author.."^9 » ^0"
					TriggerClientEvent('chatMessage', -1, tag.." "..message)
				elseif vRP.isUserBronzeVip({user_id}) then
					tag = "^9[ ^5"..user_id.." ^9] ^5VIP "..vRP.getUserVipTitle({user_id}).." ^9| ^5"..author.."^9 » ^0"
					TriggerClientEvent('chatMessage', -1, tag.." "..message)
				elseif vRP.hasGroup({user_id,"sponsors"}) then
					local theTag = vRP.getSponsorTag({user_id})
					if(theTag ~= false)then
						tag = "^9[ ^5"..user_id.." ^9] ^5"..theTag.." ^9| ^5"..author.."^9 » ^0"
					else
						tag = "^9[ ^5"..user_id.." ^9] ^5🔥Sponsor🔥 ^9| ^5"..author.."^9 » ^0"
					end
					TriggerClientEvent('chatMessage', -1, tag.." "..message)
				elseif vRP.hasGroup({user_id,"youtuber"}) then
					tag = "^9[ ^5"..user_id.." ^9] ^5VIP "..vRP.getUserVipTitle({user_id}).." ^9| ^5"..author.."^9 » ^0"
					TriggerClientEvent('chatMessage', -1, tag.." "..message)
					print("[ "..user_id.." ] ", author.." » "..message)
					PerformHttpRequest(chatwebhook, function(err, text, headers) end, 'POST', json.encode({username = "[ "..user_id.." ] "..author, content = message}), { ['Content-Type'] = 'application/json' })
				else
					CancelEvent()
					TriggerClientEvent('chatMessage', source, "[^5Krown^0] ^1Discutia este momentan dezactivata!")
				end
			elseif not WasEventCanceled() and not disabled then
				if mute[user_id] ~= true then
					if cooldown[user_id] ~= true then
						if vRP.isUserFondator({user_id}) then
							tag = "[ ^8"..user_id.." ^0] 👑 | ^9𝙁𝙊𝙉𝘿𝘼𝙏𝙊𝙍 ^0| "..author.."^8 » ^0"
						elseif vRP.isUserHead({user_id}) then
							tag = "[ ^8"..user_id.." ^0] ⭐️ | ^9Co-Fondator ^0| "..author.."^8 » ^0"
						elseif vRP.isUserSupporter({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^2Head of Staff ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserHeadAdmin({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^2Supervizor Staff ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserSuperAdmin({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^8Super Admin ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserAdmin({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^8Admin ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserSuperMod({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^3Super Moderator ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserMod({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^1Moderator ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserHelperAvansat({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^6Helper Avansat ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserHelper({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^6Helper ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserTrialHelper({user_id}) then
							tag = "[ ^8"..user_id.." ^0] | ^6Helper in Teste ツ^0| "..author.."^8 » ^0"
						elseif vRP.isUserPlatinumVip({user_id}) then
							tag = "[ ^6"..user_id.." ^0] | ^6🔮 Vip Krown ^0| "..author.."^6 » ^0"
						elseif vRP.hasGroup({user_id,"youtuber"}) then
							tag = "[ ^0"..user_id.." ^0] | ^0You^8Tube ^0| "..author.."^0 » ^0"
						elseif vRP.hasGroup({user_id,"sponsors"}) then
							local theTag = vRP.getSponsorTag({user_id})
							if(theTag ~= false)then
								tag = "^5["..user_id.."] "..theTag.." ^7| "..author.." » ^5"
							else
								tag = "[ ^3"..user_id.." ^0] | ^3🔥 Sponsor ^0| "..author.."^3 » ^0"
							end
						elseif vRP.hasGroup({user_id,"dealer arme"}) then
							tag = "^2["..user_id.."] Dealer Arme ^7| "..author.." » ^9"
						elseif vRP.isUserPlatinumVip({user_id}) then
							tag = "[ ^5"..user_id.." ^0] | ^3💎 VIP Krown ^0| "..author.."^5 » ^0"	
						elseif vRP.isUserGoldVip({user_id}) then
							tag = "[ ^3"..user_id.." ^0] | ^3🥇 VIP Gold ^0| "..author.."^3 » ^0"	
						elseif vRP.isUserSilverVip({user_id}) then
							tag = "[ ^0"..user_id.." ^0] | ^0🥈 VIP Silver ^0| "..author.."^0 » ^0"		
						elseif vRP.isUserBronzeVip({user_id}) then
							tag = "[ ^1"..user_id.." ^0] | ^1🥉 VIP Bronze ^0| "..author.."^1 » ^0"
						elseif vRP.isUserInFaction({user_id,"Politie"}) then
							local dutyStats = ""
							if(vRP.hasGroup({user_id,"onduty"}))then
								dutyStats = ""
							else
								dutyStats = "[OFF-DUTY] "
							end
							tag = "[ ^0"..user_id.." ^0] | "..dutyStats.." ^5👮Politist ^0| "..author.."^5 » ^0"	
						elseif vRP.isUserInFaction({user_id,"Armata Romana"}) then
							local dutyStats = ""
							if(vRP.hasGroup({user_id,"onduty"}))then
								dutyStats = ""
							else
								dutyStats = "[OFF-DUTY] "
							end
							tag = "[ ^0"..user_id.." ^0] | "..dutyStats.." ^5🛡️Armata Romana ^0| "..author.."^5 » ^0"
						elseif vRP.isUserInFaction({user_id,"SWAT"}) then
							local dutyStats = ""
							if(vRP.hasGroup({user_id,"onduty"}))then
								dutyStats = ""
							else
								dutyStats = "[OFF-DUTY] "
							end
							tag = "[ ^0"..user_id.." ^0] | "..dutyStats.." ^5🚓Jandarm ^0| "..author.."^5 » ^0"
						elseif vRP.isUserInFaction({user_id,"S.R.I"}) then
							local dutyStats = ""
							if(vRP.hasGroup({user_id,"onduty"}))then
								dutyStats = ""
							else
								dutyStats = "[OFF-DUTY] "
							end
							tag = "[ ^0"..user_id.." ^0] | "..dutyStats.." ^5🔫S.R.I ^0| "..author.."^5 » ^0"
						elseif vRP.isUserInFaction({user_id,"Smurd"}) then
							local dutyStats = ""
							if(vRP.hasGroup({user_id,"onduty"}))then
								dutyStats = ""
							else
								dutyStats = "[OFF-DUTY] "
							end
							tag = "[ ^0"..user_id.." ^0] | "..dutyStats.." ^6💊Medic ^0| "..author.."^6 » ^0"
						elseif vRP.isUserInFaction({user_id,"Hitman"}) then
							tag = "[ ^4"..user_id.." ^0] | ^4🗡️Hitman ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Sindicat"}) then
							tag = "[ ^4"..user_id.." ^0] | ^4🎱 Sindicat ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Cartel Sinaloa"}) then
							tag = "[ ^1"..user_id.." ^0] | ^1🔪 Cartel Sinaloa ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Cartel Medellin"}) then
							tag = "[ ^6"..user_id.." ^0] | ^6🌿 Cartel Medellin ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Los Vagos"}) then
							tag = "[ ^3"..user_id.." ^0] | ^3⚡️ Los Vagos ^0| "..author.."^0 » ^0"
							--------------------------------------------------------------
						elseif vRP.isUserInFaction({user_id,"Camorra"}) then
							tag = "[ ^3"..user_id.." ^0] | ^3👑 Camorra ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Yakuza"}) then
							tag = "[ ^0"..user_id.." ^0] | ^0🃏 Yakuza ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Rusa"}) then
							tag = "[ ^4"..user_id.." ^0] | ^4💀 Mafia Rusa ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Ndragheta"}) then
							tag = "[ ^2"..user_id.." ^0] | ^2🎩 Ndragheta ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Sopranos"}) then
							tag = "[ ^4"..user_id.." ^0] | ^4🏹 Sopranos ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"La Familia"}) then
							tag = "[ ^5"..user_id.." ^0] | ^5💲 La Familia ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Grove Street"}) then
							tag = "[ ^2"..user_id.." ^0] | ^2📗Grove Streets ^0| "..author.."^0 » ^0"
						elseif vRP.isUserInFaction({user_id,"Dealer Arme Oras"}) then
							tag = "^4[ "..user_id.." ] Dealer Arme Oras ^7| "..author.." » ^4"
						elseif vRP.isUserInFaction({user_id,"Krown News"}) then
							tag = "^9[ "..user_id.." ] Krown News ^5| "..author.." » ^9"
						elseif vRP.isUserInFaction({user_id,"Dealer Arme Sandy"}) then
							tag = "^4[ "..user_id.." ] Dealer Arme Sandy ^7| "..author.." » ^4"

						elseif vRP.isUserInFaction({user_id,"Mecanic"}) then
							tag = "^4[ "..user_id.." ] 🔧Mecanic🔧 ^7| "..author.." » ^4"
						elseif vRP.isUserInFaction({user_id,"Taxi"}) then
							tag = "^3[ "..user_id.." ] 🚕Taxi🚕 ^7| "..author.." » ^3"
						else
							tag = "[ "..user_id.." ] Cetatean | "..author.." » "
						end
						TriggerClientEvent('chatMessage', -1, tag.." "..message)
						cooldownChat(user_id)
						print("[ "..user_id.." ] ", author.." » "..message)
						PerformHttpRequest(chatwebhook, function(err, text, headers) end, 'POST', json.encode({username = "[ "..user_id.." ] "..author, content = message}), { ['Content-Type'] = 'application/json' })
					else
						TriggerClientEvent('chatMessage', source, "[^5Krown^0] Asteapta ^5"..cooldownTime.." ^0secunde pentru a putea trimite alt mesaj!")
					end
				else
					TriggerClientEvent('chatMessage', source, "^1[Mute] ^0Se pare ca nu te-ai comportat frumos pe chat si ai primit ^1mute. ^0Acesta expira in ^1"..math.floor(tonumber(timpmute[user_id]/60000)).." ^0minute")
				end
			end
		end
	end
end)

AddEventHandler('__cfx_internal:commandFallback', function(command)
	if source ~= nil then
		local name = vRP.getPlayerName({source})
		local user_id = vRP.getUserId({source})
		if user_id ~= nil then
			if not vRP.isUserTrialHelper({user_id}) or not vRP.hasGroup({user_id,"youtuber"}) or not vRP.hasGroup({user_id,"sponsors"}) or not vRP.isUserVip({user_id}) then
				name = sanitizeString(name, "^", false)
				command = sanitizeString(command, "^", false)
			end
			TriggerEvent('chatMessage', source, name, "/"..command)
			if not WasEventCanceled() then
				if mute[user_id] ~= true then
					if cooldown[user_id] ~= true then
						if disabled then
							if not vRP.isUserHelper({user_id}) then
								CancelEvent()
								TriggerClientEvent('chatMessage', source, "[^5Krown^0] Discutia este momentan dezactivata!")
							end
						else
							--TriggerClientEvent('chatMessage', -1, "[ "..user_id.." ] "..name.." » /"..command)
						end
						cooldownChat(user_id)
					else
						TriggerClientEvent('chatMessage', source, "[^5Krown^0] Asteapta ^55 ^0secunde pentru a putea trimite alt mesaj!")
					end
				else
					TriggerClientEvent('chatMessage', source, "^1[Mute] ^0Se pare ca nu te-ai comportat frumos pe chat si ai primit ^1mute. ^0Acesta expira in ^1"..math.floor(tonumber(timpmute[user_id]/60000)).." ^0minute")
				end
			end
			CancelEvent()
		end
	end
end)

local factions = {
	"SWAT",
	"Politie",
	"S.R.I",
	"Smurd",
	"Santa Rosa de Lima Cartel",
	"Anonymous",
	"La Familia",
	"Mafia Araba",
	"Triadele Chinezesti",
	"Sons of Anarchy",
	"Reyess Latinos",
	"Grove Street",
	"The Black Hand",
	"Sofer Primar",
	"Cosa Nostra",
	"Diablos",
	"MS-13",
	"BadManners",
	"Bratva",
	"Yakuza",
	"Azteca el Diablo",
	"Ndragheta",
	"Casa Blanca",
	"Clanul Duduianu",
	"Cruz Del Diablo",
	"Cartel Sinaloa",
	"Clanul Carpaci",
	"Yakuza",
	"Armata Romana",
	"Cartel Medelin"
}

RegisterCommand('f', function(source, args, rawCommand)
	if source ~= nil then
		if(args[1] == nil)then
			TriggerClientEvent('chatMessage', source, "^3SYNTAXA: /"..rawCommand.." [MESAJ]") 
		else
			local user_id = vRP.getUserId({source})
			if user_id ~= nil then
				local theFaction = ""
				for i, v in pairs(factions) do
					if vRP.isUserInFaction({user_id,tostring(v)}) then
						theFaction = tostring(v)
					end
				end
				local fMembers = vRP.getOnlineUsersByFaction({tostring(theFaction)})
				for i, v in ipairs(fMembers) do
					local player = vRP.getUserSource({tonumber(v)})
					if mute[user_id] ~= true then
						TriggerClientEvent('chatMessage', player, "^5["..theFaction.."] ^7| [ "..user_id.." ] "..vRP.getPlayerName({source}).." » ".. rawCommand:sub(3))
					else
						TriggerClientEvent('chatMessage', source, "^1[Mute] ^0Se pare ca nu te-ai comportat frumos pe chat si ai primit ^1mute. ^0Acesta expira in ^1"..math.floor(tonumber(timpmute[user_id]/60000)).." ^0minute")
					end
				end
			end
		end
	end
end, false)

RegisterCommand('fix', function(source)
	local user_id = vRP.getUserId({source})
	if vRP.isUserTrialHelper({user_id}) then
		TriggerClientEvent("murtaza:fix", source)
		
		local embed = {
						{
						  ["color"] = 1234521,
						  ["title"] = "__".. "FIX VEH".."__",
						  ["description"] = "[ "..GetPlayerName(source).." ] ( "..user_id.." ) a folosit comanda [ /fix ] ",
						  ["thumbnail"] = {
							["url"] = "https://i.imgur.com/Bi2iC6K.png",
						  },
						  ["footer"] = {
						  ["text"] = "",
						  },
						}
  }
  PerformHttpRequest('', function(err, text, headers) end, 'POST', json.encode({username = name, embeds = embed}), { ['Content-Type'] = 'application/json' })

		
	else
		TriggerClientEvent("chatMessage", source, "Nu ai acces la aceasta comanda sefule.")
	end
end)

RegisterCommand('say', function(source, args, rawCommand)
	if(source == 0)then
		TriggerClientEvent('chatMessage', -1, "^9[CONSOLA] ^1"..rawCommand:sub(5))
	elseif source ~= nil then
		local user_id = vRP.getUserId({source})
		if user_id ~= nil then
			if vRP.isUserCoOwner({user_id}) then
				TriggerClientEvent('chatMessage', -1, "^9["..vRP.getPlayerName({source}).."] ^1"..rawCommand:sub(5))
			end
		end
	end
end, false)

RegisterCommand('car', function(source, args, rawCommand)
	local user_id = vRP.getUserId({source})
	local player = vRP.getUserSource{user_id}
	if user_id ~= nil then
		if vRP.isUserAdmin({user_id}) then
			if args[1] ~= nil then
				vRPclient.spawnVehicle(player,{tostring(args[1])})
			else
				vRPclient.notify(player,{"Model invalid!"})
			end
		else
			vRPclient.notify(player,{"Nu ai acces!"})
		end
	end
end, false)

RegisterCommand("arevive",function(source,args)
	local thePlayer = source
	local user_id = vRP.getUserId({thePlayer})
	local playerName = GetPlayerName(thePlayer)
	local isAdmin = vRP.isUserTrialHelper({user_id})
	local thePlayers = vRP.getUsers({})
	if (isAdmin) then
		local id = args[1]
		if parseInt(id) > 0 then
			local nuser_id = parseInt(id)
			local nplayer = vRP.getUserSource({nuser_id})
			if nplayer then
				vRPclient.isInComa(nplayer,{}, function(in_coma)
					if in_coma then
						nplayername = GetPlayerName(nplayer)
						--vRP.addNewLog({user_id, 4, "ARevive -> "..playerName.." -> "..nplayername})
						TriggerClientEvent("chatMessage",-1,"^1ARevive^0: "..playerName.." -> "..nplayername.."")
						vRPclient.notify(nplayer,{"I-ai dat revive lui ~g~"..nplayername})
						vRPclient.notify(nplayer,{"Ai primit revive de la adminul ~g~"..playerName})
						vRPclient.varyHealth(nplayer,{200})
					else
						TriggerClientEvent("chatMessage",thePlayer,"^1Eroare:^0 Acest jucator nu este mort!")
					end
				end)
			else
				TriggerClientEvent("chatMessage",thePlayer,"^1Eroare:^0 Acest jucator nu este online!")
			end
		elseif tostring(id) == "all" then
			TriggerClientEvent("chatMessage",-1,"^1ARevive^0: Adminul ^1"..playerName.."^0 a dat revive la tot serverul!")
		--	vRP.addNewLog({user_id, 4, "ARevive -> "..playerName.." -> a dat revive la tot serverul!"})
			for k,v in pairs(thePlayers)do

				thePlayersIds = v
				theIDs = k
				vRPclient.isInComa(thePlayers,{}, function(in_coma)
					if in_coma then
						vRPclient.revive(thePlayersIds,{})
						vRPclient.notify(thePlayersIds,{"Ai primit revive de la adminul ~g~"..playerName})
					end
				end)
			end
		end
	else
		TriggerClientEvent("chatMessage",thePlayer,"^1Eroare:^0 Nu ai acces la aceasta comanda!")
	end
end)

RegisterCommand("nc", function(player)
	local user_id = vRP.getUserId({player})
	if vRP.isUserAdmin({user_id}) then
		vRPclient.toggleNoclip(player, {})
	else
		TriggerClientEvent("chatMessage", player, "^1Eroare^0: Nu ai acces la aceasta comanda.")
	end
end)

function daicumute(user_id, type)
	if(type)then
		--[[if timpmutevoice[user_id] ~= nil then
			Wait(timpmutevoice[user_id])
			timpmutevoice[user_id] = nil
			mutevoice[user_id] = nil
		end]]
	else
		if timpmute[user_id] ~= nil then
			Wait(timpmute[user_id])
			timpmute[user_id] = nil
			mute[user_id] = nil
		end
	end
end

RegisterCommand('mute', function(source, args, rawCommand)
	if source == 0 then
		if(args[1] == nil)then
			print("Pune Bro Un ID")
		else
			local user_id = tonumber(args[1])
			local guy = vRP.getUserSource({user_id})
			if guy ~= nil then
				if mute[user_id] == true then
					timpmute[user_id] = nil
					mute[user_id] = nil
					TriggerClientEvent('chatMessage', -1, "^1[Mute] ^0Se pare ca ^1"..vRP.getPlayerName({vRP.getUserSource({user_id})}).."^0 a primit unmute de la ^1Consola")
				else
					if args[2] ~= nil then
						timpmute[user_id] = tonumber(args[2])*60000
						mute[user_id] = true
						TriggerClientEvent('chatMessage', -1, "^1[Mute] ^0Se pare ca ^1"..vRP.getPlayerName({vRP.getUserSource({user_id})}).."^0 a primit mute de la ^1Consola ^0timp de ^1"..tonumber(args[2]).." ^0minute")
						daicumute(user_id, false)
					else
						print("Pune Bro Minutele")
					end
				end
			else
				print("Jucator Offline")
			end
		end
	elseif source ~= nil then
		local user_id = vRP.getUserId({source})
		if user_id ~= nil then
			if(args[1] == nil)then
				TriggerClientEvent('chatMessage', source, "^1SYNTAXA: /"..rawCommand.." [ID] [MINUTE]") 
			else
				if vRP.isUserTrialHelper({user_id}) then
					local target_id = tonumber(args[1])
					local guy = vRP.getUserSource({target_id})
					if guy ~= nil then
						if mute[target_id] == true then
							timpmute[target_id] = nil
							mute[target_id] = nil
							TriggerClientEvent('chatMessage', -1, "^1[Mute] ^0Se pare ca ^1"..vRP.getPlayerName({vRP.getUserSource({target_id})}).."^0 a primit unmute de la ^1"..vRP.getPlayerName({source}))
						else
							if args[2] ~= nil then
								timpmute[target_id] = tonumber(args[2])*60000
								mute[target_id] = true
								TriggerClientEvent('chatMessage', -1, "^1[Mute] ^0Se pare ca ^1"..vRP.getPlayerName({vRP.getUserSource({target_id})}).."^0 a primit mute de la ^1"..vRP.getPlayerName({source}).." ^0timp de ^1"..tonumber(args[2]).." ^0minute")
								daicumute(target_id, false)
							end
						end
					else
						vRPclient.notify(source,{"[~b~Krown~w~] ~r~Jucatorul nu este pe server!"})
					end
				end
			end
		end
	end
end, false)

--[[RegisterCommand('mutevoice', function(source, args, rawCommand)
	if source == 0 then
		if(args[1] == nil)then
			print("Pune Bro Un ID")
		else
			local user_id = tonumber(args[1])
			local guy = vRP.getUserSource({user_id})
			if guy ~= nil then
				if mutevoice[user_id] == true then
					timpmutevoice[user_id] = nil
					mutevoice[user_id] = nil
					TriggerClientEvent('chatMessage', -1, "^1[Mute] ^0Se pare ca ^1"..vRP.getPlayerName({vRP.getUserSource({user_id})}).."^0 a primit unmute voice de la ^1Consola")
					vRPclient.setUserVoiceMuted(guy, {false})
				else
					if args[2] ~= nil then
						timpmutevoice[user_id] = tonumber(args[2])*60000
						mutevoice[user_id] = true
						TriggerClientEvent('chatMessage', -1, "^1[Mute] ^0Se pare ca ^1"..vRP.getPlayerName({vRP.getUserSource({user_id})}).."^0 a primit mute voice de la ^1Consola ^0timp de ^1"..tonumber(args[2]).." ^0minute")
						vRPclient.setUserVoiceMuted(guy, {true})
						daicumute(user_id, true)
					else
						print("Pune Bro Minutele")
					end
				end
			else
				print("Jucator Offline")
			end
		end
	elseif source ~= nil then
		local user_id = vRP.getUserId({source})
		if user_id ~= nil then
			if(args[1] == nil)then
				TriggerClientEvent('chatMessage', source, "^1SYNTAXA: /"..rawCommand.." [ID] [MINUTE]") 
			else
				if vRP.isUserTrialHelper({user_id}) then
					local target_id = tonumber(args[1])
					local guy = vRP.getUserSource({target_id})
					if guy ~= nil then
						if mutevoice[target_id] == true then
							timpmutevoice[target_id] = nil
							mutevoice[target_id] = nil
							TriggerClientEvent('chatMessage', -1, "^1[Mute] ^0Se pare ca ^1"..vRP.getPlayerName({vRP.getUserSource({target_id})}).."^0 a primit unmute voice de la ^1"..vRP.getPlayerName({source}))
							vRPclient.setUserVoiceMuted(guy, {false})
						else
							if args[2] ~= nil then
								timpmutevoice[target_id] = tonumber(args[2])*60000
								mutevoice[target_id] = true
								TriggerClientEvent('chatMessage', -1, "^1[Mute] ^0Se pare ca ^1"..vRP.getPlayerName({vRP.getUserSource({target_id})}).."^0 a primit mute voice de la ^1"..vRP.getPlayerName({source}).." ^0timp de ^1"..tonumber(args[2]).." ^0minute")
								vRPclient.setUserVoiceMuted(guy, {true})
								daicumute(target_id, true)
							end
						end
					else
						vRPclient.notify(source,{"[~b~Krown~w~] ~r~Jucatorul nu este pe server!"})
					end
				end
			end
		end
	end
end, false)]]


local function giveAllBankMoney(suma)
	local jucatori = vRP.getUsers({})
	for i, v in pairs(jucatori) do
		vRP.giveBankMoney({i, tonumber(suma)})
	end
end

RegisterCommand("givemoneyall", function(source, args, rawCommand)
	if source == 0 then
		local theMoney = parseInt(args[1])
		if theMoney ~= nil and theMoney > 0 then
			giveAllBankMoney(theMoney)
			TriggerClientEvent('chatMessage', -1, "[^5Krown^0] ^1Consola ^0a dat un bonus de ^1"..vRP.formatMoney({theMoney}).."$ ^0tuturor jucatorilor")
			print("Dat Cu Succes "..vRP.formatMoney({theMoney}).."$ La Toti Jucatorii!")
		end
	elseif source ~= nil then
		local user_id = vRP.getUserId({source})
		if user_id ~= nil then
			if(args[1] == nil)then
				TriggerClientEvent('chatMessage', source, "^1SYNTAXA: /"..rawCommand.." [SUMA]")
			else
				if vRP.isUserCoOwner({user_id}) then
					local theMoney = parseInt(args[1])
					if theMoney ~= nil and theMoney > 0 then
						giveAllBankMoney(args[1])
						TriggerClientEvent('chatMessage', -1, "[^5Krown^0] ^1"..vRP.getPlayerName({source}).." ^0a dat un bonus de ^1"..vRP.formatMoney({theMoney}).."$ ^0tuturor jucatorilor")
					end
				end
			end
		end
	end
end, false)

RegisterCommand("givemoney", function(source, args, rawCommand)
	if source == 0 then
		local user_id = parseInt(args[1])
		if user_id ~= nil and user_id > 0 then
			local theMoney = parseInt(args[2])
			if theMoney ~= nil and theMoney > 0 then
				local guy = vRP.getUserSource({user_id})
				if guy ~= nil then
					vRP.giveBankMoney({user_id,theMoney})
					print("Dat Cu Succes $"..vRP.formatMoney({theMoney}).." Lui ID "..user_id)
				else
					print("Jucator Offline")
				end
			else
				print("Pune Bro O Suma")
			end
		else
			print("Pune Bro Un ID")
		end
	end
end, false)

local function giveAcAll(suma)
    local jucatori = vRP.getUsers({})
    for i, v in pairs(jucatori) do
        vRP.giveAC({i, tonumber(suma)})
    end
end

RegisterCommand("giveallac", function(source, args, rawCommand)
    if source == 0 then
        local theMoney = parseInt(args[1])
        if theMoney ~= nil and theMoney > 0 then
            giveAcAll(theMoney)
            TriggerClientEvent('chatMessage', -1, "[^5Krown^0] ^1Consola ^0a dat un bonus de ^1"..vRP.formatMoney({theMoney}).." Krown Coins ^0tuturor jucatorilor")
            print("Dat Cu Succes "..vRP.formatMoney({theMoney}).."$ La Toti Jucatorii!")
        end
    elseif source ~= nil then
        local user_id = vRP.getUserId({source})
        if user_id ~= nil then
            if(args[1] == nil)then
                TriggerClientEvent('chatMessage', source, "^1SYNTAXA: /"..rawCommand.." [SUMA]")
            else
                if vRP.isUserHardDmd({user_id}) then
                    local theMoney = parseInt(args[1])
                    if theMoney ~= nil and theMoney > 0 then
                        giveAcAll(args[1])
                        TriggerClientEvent('chatMessage', -1, "[^5Krown^0] ^1"..vRP.getPlayerName({source}).." ^0a dat un bonus de ^1"..vRP.formatMoney({theMoney}).." Krown Coins ^0tuturor jucatorilor")
                    end
                end
            end
        end
    end
end, false)

RegisterCommand('a', function(source, args, rawCommand)
	if source ~= nil then
		local user_id = vRP.getUserId({source})
		if user_id ~= nil then
			if(args[1] == nil)then
				TriggerClientEvent('chatMessage', source, "^1SYNTAXA: /"..rawCommand.." [MESAJ]") 
			else
				if(vRP.isUserTrialHelper({user_id}))then
					if mute[user_id] ~= true then
						vRP.sendStaffMessage({"^1Staff-Chat^0 | [ "..user_id.." ] "..vRP.getPlayerName({source}).." » ^1"..rawCommand:sub(3)})
					else
						TriggerClientEvent('chatMessage', source, "^1[Mute] ^0Se pare ca nu te-ai comportat frumos pe chat si ai primit ^1mute. ^0Acesta expira in ^1"..math.floor(tonumber(timpmute[user_id]/60000)).." ^0minute")
					end
				end
			end
		end
	end
end, false)

RegisterCommand('discord', function(source)
	if source ~= nil then
		TriggerClientEvent('chatMessage', source, "[^5Krown^0] Discord-ul Server-ului Este » ^5discord.gg/KrownRO")
	end
end, false)

RegisterCommand("respawn", function(player, args)
	local user_id = vRP.getUserId({player})
	if vRP.isUserTrialHelper({user_id}) then
		local target_id = parseInt(args[1])
		local target_src = vRP.getUserSource({target_id})
		if target_src then
			vRPclient.teleport(target_src, {-140.7081451416,6306.5356445312,31.526853561402})
        	vRPclient.varyHealth(target_src, {100})
			TriggerClientEvent("chatMessage", target_src, "^1Info^7: Ai fost respawnat de catre un admin!")
			vRP.sendStaffMessage({"^0Admin-ul ^8"..GetPlayerName(player).." ^0i-a dat respawn lui ^8"..GetPlayerName(target_src)})
		else
			TriggerClientEvent("chatMessage", player, "^1Comanda^7: /respawn <ID>")
		end
	else
		TriggerClientEvent('chatMessage', source, "[^5Krown^0] Nu ai permisiune de a da respawn.")
	end
end, false)

RegisterCommand('clear', function(source)
    local user_id = vRP.getUserId({source});
    if user_id ~= nil then
        if vRP.hasPermission({user_id, "admin.tickets"}) then
            TriggerClientEvent("chat:clear", -1);
            TriggerClientEvent("sonydamuielasclavi", -1, "[^5Krown^0]: Adminul ^1".. GetPlayerName(source) .."^0 a sters tot chat-ul.");
        else
            TriggerClientEvent("sonydamuielasclavi", source, "^1Eroare^0: Nu ai acces la aceasta comanda.");
        end
    end
end)
RegisterServerEvent('chat:clear')

--[[AddEventHandler("vRP:playerSpawn",function(user_id,source,first_spawn)
	if first_spawn then
		if timpmutevoice[user_id] ~= nil and mutevoice[user_id] ~= nil then
			vRPclient.setUserVoiceMuted(source, {true})
		end
	end
end)]]

RegisterNetEvent("SV:editMessage")
AddEventHandler("SV:editMessage",function(data)
--	print(data.messageId)
	TriggerClientEvent('CL:changeMessage', -1, data)
end)


